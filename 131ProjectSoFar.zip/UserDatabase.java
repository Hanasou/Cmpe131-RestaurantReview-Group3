import java.util.HashMap;
/**
 *  This class is responsible for maintaining user database which is
 *  used for a log in functionality of the program.
 *
 * Team 7 Restaurant Review Application
 * @version 1.0
 */
public class UserDatabase
{
  private HashMap<String,String> userAccount; // instance variable to store unique combination of username and password 
  private String username;     // instance variable for username
  private String password;     // instance variable for password
  
  /*********************
   *  Constructor. Creates a new instance of a Hash Map that will hold
   *  user information (user name and password).
   *  
   *  @version 1.0
   */
  public UserDatabase()
  {
     userAccount = new HashMap();    
  }
  
  /**********************
   * A getter method for the username instance variable
   * 
   * @return returns the username of a user in user database
   * @version 1.0
   */
  public String getUsername()
  {
     return username;    
  }
  
  /********************************
   * This method is responsible for adding a user into a user database
   *  
   *  @param 2 strings, a user name and a password
   *  @version 1.0
   */
  public void setAccount(String username, String password)
  {
      this.username = username;
      this.password = password;
      userAccount.put(username,password);    
  }
  
  /*********************************
   * This method validates the log in (checks whether log in 
   * and password match) 
   * 
   * @param 2 strings, a user name and a password
   * @return returns a boolean value denoting whether a validation 
   *          process succeeded
   * @version 1.0
   */ 
  public boolean validateLogIn(String username, String password)
  {
      if(userAccount.containsKey(username))  // if there is a username in database
        {
            if(userAccount.get(username).equals(password)) // check if password matches
               return true;
        }   
      return false; 
    }
  
  /**********************************
   * This method determines if a user entered the wrong password
   * 
   * @param 2 strings, a user name and a password
   * @return returns a boolean value denoting whether or not a user
   *         entered incorrect password
   * @version 1.0
   */
  // this method determines if a user entered the wrong password
  public boolean wrongPassword(String username, String password)
  {
     // return true if username is in database but the password does not match
     return userAccount.containsKey(username) 
                && !userAccount.get(username).equals(password);   
   }
   
  /***********************************
   * This method checks whether a user is registered (username is in database)
   * 
   * @param a string representing user name
   * @return returns a boolean value denoting if a user is not in user 
   *          database
   * @version 1.0
   */
  // this method checks whether a user is registered (username is in database)
  public boolean noAccountExists(String username)
  {
      // return true if username is not in database
      return !userAccount.containsKey(username);   
   }
}

