import javax.swing.*;
import java.awt.event.*;
import java.awt.Image;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Color;
/**
 * Write a description of class LogOutScreen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LogOutScreen extends JFrame
{
   private JFrame logOutFrame;
   
   public void createLogOutFrame()
   {
      logOutFrame = new JFrame("Log out screen");
      JLabel logOut = new JLabel("You are logged out.");
      logOut.setFont(new Font("Sarif", Font.PLAIN, 40));
      JLabel nextLabel = new JLabel("Thanks for visiting! Hope to see you back soon!");
      nextLabel.setFont(new Font("Sarif", Font.PLAIN, 40));
      JButton startOver = new JButton("Start over");
      
      ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/Desktop/131ProjectNoState/ThumbsUp.png");
      Image picture = image.getImage();
      Image newImage = picture.getScaledInstance(800,400,Image.SCALE_SMOOTH);
      image = new ImageIcon(newImage);
      JLabel imageLabel = new JLabel(image);
      
      JPanel imagePanel = new JPanel();
      imagePanel.add(imageLabel);
      imagePanel.setBackground(Color.RED);
      imagePanel.setMaximumSize(new Dimension(2000,410));
      
      JPanel logOutPanel = new JPanel();
      logOutPanel.add(Box.createHorizontalStrut(150));
      logOutPanel.add(logOut);
      logOutPanel.setBackground(Color.GREEN);
      logOutPanel.setMaximumSize(new Dimension(2000,100));
      
      JPanel lowerPanel = new JPanel();
      lowerPanel.add(nextLabel);
      lowerPanel.setMaximumSize(new Dimension(2000,100));
      lowerPanel.setBackground(Color.BLUE);
      
      JPanel centerPanel = new JPanel();
      centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
      centerPanel.add(imagePanel);
      centerPanel.add(logOutPanel);
      centerPanel.add(lowerPanel);
      centerPanel.add(startOver);
      
      JPanel finalPanel = new JPanel(new BorderLayout());
      finalPanel.add(centerPanel, BorderLayout.CENTER);
      
      startOver.addActionListener(new ActionListener()   {
              public void actionPerformed(ActionEvent e)
              {
                  hideScreen();
                  LogInScreen screen = new LogInScreen();
                  screen.createLogInPage();
                }
        });
      logOutFrame.add(finalPanel);
      logOutFrame.setPreferredSize(new Dimension(2000,2000));
      logOutFrame.pack();
      logOutFrame.setVisible(true);
    }
    
   public void hideScreen()
   {
      logOutFrame.setVisible(false);  
    }
}
