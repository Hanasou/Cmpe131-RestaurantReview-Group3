import java.util.ArrayList;
/**
 * Write a description of class RestaurantDatabase here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RestaurantDatabase
{
   private ArrayList<String> restaurants;
   
   public RestaurantDatabase()
   {
      restaurants = new ArrayList();  
    }
    
   public ArrayList<String> getRestaurants()
   {
      return restaurants;  
    }
    
   public void addRestaurant(String restaurant)
   {
      restaurants.add(restaurant);  
    }
}
