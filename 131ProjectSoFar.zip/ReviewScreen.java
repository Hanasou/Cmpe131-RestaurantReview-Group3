import javax.swing.*;
import java.awt.event.*;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.Image;
/**
 * Write a description of class ReviewScreen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ReviewScreen extends JFrame
{
    private JFrame reviewScreen;
    
    public void createReviewScreen()
    {
        reviewScreen = new JFrame("Write Review");
        JLabel label = new JLabel("Please submit your review below:");
        label.setFont(new Font("Serif", Font.PLAIN, 30));
        label.setForeground(Color.RED);
        JLabel welcomeLabel = new JLabel("You are logged in as " + SearchScreen.username);
        welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
        JButton logOutButton = new JButton("Log out");
        
        JTextArea reviewField = new JTextArea();
        reviewField.setPreferredSize(new Dimension(400,500));
        reviewField.setLineWrap(true);
        reviewField.setWrapStyleWord(true);
        JButton submit = new JButton("Submit");
        
        ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/Desktop/131ProjectNoState/Review.jpg");
        Image picture = image.getImage();
        Image newImage = picture.getScaledInstance(1000,800,Image.SCALE_SMOOTH);
        image = new ImageIcon(newImage);
        JLabel imageLabel = new JLabel(image);
        
        JPanel welcomePanel = new JPanel();
        welcomePanel.add(welcomeLabel);
        welcomePanel.setMaximumSize(new Dimension(250,50));
        welcomePanel.setBackground(Color.GREEN);
        
        JPanel logOutPanel = new JPanel();
        logOutPanel.add(Box.createHorizontalStrut(30));
        logOutPanel.add(logOutButton);
        logOutPanel.setBackground(Color.YELLOW);
        
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.PAGE_AXIS));
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(welcomePanel);
        rightPanel.add(logOutPanel);
        rightPanel.setBackground(Color.YELLOW);
        
        JPanel labelPanel = new JPanel();
        labelPanel.add(Box.createHorizontalStrut(100));
        labelPanel.add(label);
        labelPanel.setBackground(Color.GREEN);
        labelPanel.setMaximumSize(new Dimension(2000,50));
        
        JPanel reviewPanel = new JPanel();
        reviewPanel.add(Box.createHorizontalStrut(100));
        reviewPanel.add(reviewField);
        reviewPanel.setMaximumSize(new Dimension(2000, 500));
        
        JPanel submitPanel = new JPanel();
        submitPanel.add(Box.createHorizontalStrut(400));
        submitPanel.add(submit);
        submitPanel.setMaximumSize(new Dimension(2000,50));
        submitPanel.setBackground(Color.BLUE);
        
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(labelPanel);
        centerPanel.add(reviewPanel);
        centerPanel.add(submitPanel);
        
        JPanel finalPanel = new JPanel();
        finalPanel.setLayout(new BorderLayout());
        finalPanel.add(centerPanel, BorderLayout.WEST);
        finalPanel.add(imageLabel, BorderLayout.CENTER);
        finalPanel.add(rightPanel, BorderLayout.EAST);
        
        logOutButton.addActionListener(new ActionListener()   {
            public void actionPerformed(ActionEvent e)
            {
                hideScreen();
                LogOutScreen screen = new LogOutScreen();
                screen.createLogOutFrame();
            }
        });
        
        reviewScreen.add(finalPanel);
        reviewScreen.setPreferredSize(new Dimension(2000,2000));
        reviewScreen.pack();
        reviewScreen.setVisible(true);
    }
    
    public void hideScreen()
    {
        reviewScreen.setVisible(false);   
    }
}
