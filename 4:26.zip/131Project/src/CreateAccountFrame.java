import javax.swing.*;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
public class CreateAccountFrame extends JFrame   {
     
	private JFrame accountFrame;
	
	public void createFrame()
	{
		accountFrame = new JFrame("Create Account");
		
		JLabel label = new JLabel("Please enter information below:");
		label.setFont(new Font("Sarif", Font.PLAIN, 40));
		label.setForeground(Color.BLUE);
		JLabel username = new JLabel("Username:");
		username.setFont(new Font("Sarif", Font.PLAIN, 20));
		JLabel password = new JLabel("Password:");
		password.setFont(new Font("Sarif", Font.PLAIN, 20));
		JLabel confirmPassword = new JLabel("Confirm password:");
		confirmPassword.setFont(new Font("Sarif", Font.PLAIN, 20));
		JButton create = new JButton("Create");
		JButton back = new JButton("Back to log in");
		JTextField userField = new JTextField();
		userField.setPreferredSize(new Dimension(150,20));
		JPasswordField passwordField = new JPasswordField();
		passwordField.setPreferredSize(new Dimension(150,20));
		JPasswordField confirmField = new JPasswordField();
		confirmField.setPreferredSize(new Dimension(150,20));
		
		JPanel labelPanel = new JPanel();
		labelPanel.add(Box.createHorizontalStrut(20));
		labelPanel.add(label);
		labelPanel.setMaximumSize(new Dimension(1000,100));
		
		JPanel usernamePanel = new JPanel();
		usernamePanel.add(Box.createHorizontalStrut(73));
		usernamePanel.add(username);
		usernamePanel.add(userField);
		usernamePanel.setMaximumSize(new Dimension(350,50));
		usernamePanel.setBackground(Color.RED);
		
		JPanel passwordPanel = new JPanel();
		passwordPanel.add(Box.createHorizontalStrut(80));
		passwordPanel.add(password);
		passwordPanel.add(passwordField);
		passwordPanel.setMaximumSize(new Dimension(350,50));
		passwordPanel.setBackground(Color.YELLOW);
		
		JPanel confirmPanel = new JPanel();
		confirmPanel.add(confirmPassword);
		confirmPanel.add(confirmField);
		confirmPanel.setMaximumSize(new Dimension(350,50));
		confirmPanel.setBackground(Color.GREEN);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(back);
		buttonPanel.add(Box.createHorizontalStrut(115));
		buttonPanel.add(create);
		
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
		centerPanel.add(Box.createVerticalStrut(100));
		centerPanel.add(labelPanel);
		centerPanel.add(Box.createVerticalStrut(100));
		centerPanel.add(usernamePanel);
		centerPanel.add(passwordPanel);
		centerPanel.add(confirmPanel);
		centerPanel.add(buttonPanel);
		
		JPanel finalPanel = new JPanel();
		finalPanel.setLayout(new BorderLayout());
		finalPanel.add(centerPanel, BorderLayout.CENTER);
		
		create.addActionListener(new ActionListener()    {
			public void actionPerformed(ActionEvent e) {
				String userString = userField.getText();
				String userPassword = passwordField.getText();
				String userConfirm = confirmField.getText();
				if(LoginDao.userInDatabase(userString))
				{
					JOptionPane.showMessageDialog(accountFrame, "The account with this username already exists." +
							"Please choose a different username");
					 userField.setText("");
					 passwordField.setText("");
					 confirmField.setText("");
					 userField.requestFocusInWindow();
				}
				else if(!userPassword.equals(userConfirm))
				 {
					 JOptionPane.showMessageDialog(accountFrame,  "Passwords entered must match");
					 passwordField.setText("");
					 confirmField.setText("");
					 passwordField.requestFocusInWindow();
				 }
				 else if(userPassword.length() == 0 && userConfirm.length() == 0)
				 {
					 JOptionPane.showMessageDialog(accountFrame,  "Password must contain at least 1 character");
				 }
				
				 else if(LoginDao.insertInUserDatabase(userString, userPassword))
				 {
					 hideScreen();
					 AccountConfirmationScreen screen = new AccountConfirmationScreen();
					 screen.createConfirmationFrame();
				 }
				
				/*
				 else if(UserDatabase.hasUser(userString))
				 {
					 JOptionPane.showMessageDialog(accountFrame,  "Account with this username already exists");
					 userField.setText("");
					 passwordField.setText("");
					 confirmField.setText("");
				 }
				
				 else
				 {
					 hideScreen();
					 UserDatabase.setAccount(userString, userPassword);
					 AccountConfirmationScreen screen = new AccountConfirmationScreen();
					 screen.createConfirmationFrame();
				 }
				 */
			}			
		});
		
		back.addActionListener(new ActionListener()   {
			public void actionPerformed(ActionEvent e)
			{
				hideScreen();
				LogInScreen screen = new LogInScreen();
				screen.createLogInPage();
			}
		});
		
		accountFrame.add(finalPanel);
		accountFrame.getContentPane().setBackground(Color.BLUE);
		accountFrame.setPreferredSize(new Dimension(2000,2000));
		accountFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		accountFrame.pack();
		accountFrame.setVisible(true);
	}
	
	public void hideScreen()
	{
		accountFrame.setVisible(false);
	}
}
