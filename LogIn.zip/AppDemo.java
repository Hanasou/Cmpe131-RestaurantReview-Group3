
/**
 * Write a description of class AppDemo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AppDemo
{
  public static void main(String[] args)
  {
        LogInManager manager = new LogInManager();
        manager.createLogInPage();
   }
}
