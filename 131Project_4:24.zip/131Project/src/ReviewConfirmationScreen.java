import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;

public class ReviewConfirmationScreen extends JFrame     {

	private JFrame confirmScreen;
	
	public void createScreen()
	{
		confirmScreen = new JFrame("Confirm Review Submission");
		JLabel welcomeLabel = new JLabel("You are logged in as " + SearchScreen.username);
	    welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
	    JButton logOutButton = new JButton("Log out");
		
	    JPanel welcomePanel = new JPanel();
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createHorizontalStrut(20));
        welcomePanel.setMaximumSize(new Dimension(300,50));
        welcomePanel.setBackground(Color.RED);
        
        JPanel logOutPanel = new JPanel();
        logOutPanel.add(Box.createHorizontalStrut(150));
        logOutPanel.add(logOutButton);
        logOutPanel.setMaximumSize(new Dimension(300,50));
        logOutPanel.setBackground(Color.GREEN);
        
        JPanel eastPanel = new JPanel();
        eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.PAGE_AXIS));
        eastPanel.add(welcomePanel);
        eastPanel.add(logOutPanel);
        
        JPanel finalPanel = new JPanel();
        finalPanel.setLayout(new BorderLayout());
        finalPanel.add(eastPanel, BorderLayout.EAST);
        
        logOutButton.addActionListener(new ActionListener()   {
        	        public void actionPerformed(ActionEvent e)
        	        {
        	        	  hideScreen();
        	        	  LogOutScreen screen = new LogOutScreen();
        	        	  screen.createLogOutFrame();
        	        }
        });
        
	    confirmScreen.add(finalPanel);
	    confirmScreen.setDefaultCloseOperation(EXIT_ON_CLOSE);
		confirmScreen.setPreferredSize(new Dimension(2000,2000));
		confirmScreen.pack();
		confirmScreen.setVisible(true);
	}
	
	public void hideScreen()
	{
		confirmScreen.setVisible(false);
	}
}
