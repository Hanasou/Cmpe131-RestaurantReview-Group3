import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

public class DisplayReviewsScreen extends JFrame {

	private JFrame displayScreen;
	
	public void createScreen(String restaurant, ArrayList<String> reviews)
	{
		displayScreen = new JFrame("Display Available Reviews");
		JLabel welcomeLabel = new JLabel("You are logged in as " + SearchScreen.username);
	    welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
	    JButton logOutButton = new JButton("Log out");
	    JLabel topLabel = new JLabel("Displaying available reviews for " + restaurant + ":");
	    topLabel.setFont(new Font("Serif", Font.PLAIN, 30));
	    JButton backToResults = new JButton("Back to search results");
	    JButton newSearch = new JButton("New search");
	    JButton review = new JButton("Review this restaurant");
	    
	    JPanel buttonPanel = new JPanel();
	    buttonPanel.add(backToResults);
	    buttonPanel.add(Box.createHorizontalStrut(50));
	    buttonPanel.add(review);
	    buttonPanel.add(Box.createHorizontalStrut(50));
	    buttonPanel.add(newSearch);
	    buttonPanel.setMaximumSize(new Dimension(1000,100));
	    
	    JPanel labelPanel = new JPanel();
	    labelPanel.add(topLabel);
	    labelPanel.setMaximumSize(new Dimension(1000,100));
	    labelPanel.setBackground(Color.BLUE);
	    
	    JPanel welcomePanel = new JPanel();
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createHorizontalStrut(20));
        welcomePanel.setMaximumSize(new Dimension(300,50));
        welcomePanel.setBackground(Color.RED);
	    
	    JPanel logOutPanel = new JPanel();
        logOutPanel.add(Box.createHorizontalStrut(150));
        logOutPanel.add(logOutButton);
        logOutPanel.setMaximumSize(new Dimension(300,50));
        logOutPanel.setBackground(Color.GREEN);
        
        JPanel eastPanel = new JPanel();
        eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.PAGE_AXIS));
        eastPanel.add(welcomePanel);
        eastPanel.add(logOutPanel);
		
        
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
        centerPanel.add(labelPanel);
        for(int i = 0; i < reviews.size(); i ++)
        {
        	   JTextArea field = new JTextArea();
        	   field.setMaximumSize(new Dimension(1000,50));
        	   field.setText(reviews.get(i));
        	   field.setLineWrap(true);
        	   field.setWrapStyleWord(true);
        	   centerPanel.add(field);
        	   centerPanel.add(Box.createVerticalStrut(20));
        }
        centerPanel.add(buttonPanel);
        
        JPanel finalPanel = new JPanel();
        finalPanel.setLayout(new BorderLayout());
        finalPanel.add(centerPanel, BorderLayout.CENTER);
        finalPanel.add(eastPanel, BorderLayout.EAST);
        
        backToResults.addActionListener(new ActionListener() {
        	       public void actionPerformed(ActionEvent e)
        	       {
        	    	      hideScreen();
        	    	      SearchScreenResult screen = new SearchScreenResult();
        	    	      screen.createFoundRestaurantScreen(restaurant);
        	       }
        });
        
        newSearch.addActionListener(new ActionListener()   {
        	      public void actionPerformed(ActionEvent e)
        	      {
        	    	     hideScreen();
        	    	     SearchScreen screen = new SearchScreen();
        	    	     screen.createPage();
        	      }
        });
        
        review.addActionListener(new ActionListener()   {
        	     public void actionPerformed(ActionEvent e)
        	     {
        	    	    hideScreen();
        	    	    ReviewScreen screen = new ReviewScreen();
        	    	    screen.createReviewScreen(restaurant);
        	     }
        });
        
        logOutButton.addActionListener(new ActionListener()   {
            public void actionPerformed(ActionEvent e)
            {
                hideScreen();
                LogOutScreen manager = new LogOutScreen();
                manager.createLogOutFrame();
            }    
        });
        
        displayScreen.add(finalPanel);
		displayScreen.setPreferredSize(new Dimension(2000,2000));
		displayScreen.setDefaultCloseOperation(EXIT_ON_CLOSE);
		displayScreen.pack();
		displayScreen.setVisible(true);
	}
	
	public void hideScreen()
	{
		displayScreen.setVisible(false);
	}
}
