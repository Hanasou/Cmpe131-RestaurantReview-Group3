
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Font;
/**
 * Write a description of class SearchScreenResult here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SearchScreenResult extends JFrame
{
    private JFrame searchResultFrame;
    
    public void createFoundRestaurantScreen(String restaurantName)
    {
        searchResultFrame = new JFrame("Search Results");
        JLabel name = new JLabel(restaurantName);
        name.setFont(new Font("Serif", Font.PLAIN, 25));
        JLabel result = new JLabel("Your search produced the following result:");
        result.setForeground(Color.RED);
        result.setFont(new Font("Serif", Font.PLAIN, 30));
        JLabel welcomeLabel = new JLabel("You are logged in as " + SearchScreen.username);
        welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
        JButton logOutButton = new JButton("Log out");
        JButton displayReview = new JButton("See reviews");
        JButton writeReview = new JButton("Write Review");
        JButton newSearch = new JButton("New Search");
        
        JPanel welcomePanel = new JPanel();
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createHorizontalStrut(10));
        welcomePanel.setMaximumSize(new Dimension(400,200));
        welcomePanel.setBackground(Color.GREEN);
        
        JPanel logOutPanel = new JPanel();
        logOutPanel.add(Box.createHorizontalStrut(20));
        logOutPanel.add(logOutButton);
        logOutPanel.setBackground(Color.GREEN);
        
        JPanel topLeftPanel = new JPanel();
        topLeftPanel.setLayout(new BoxLayout(topLeftPanel, BoxLayout.PAGE_AXIS));
        topLeftPanel.setBackground(Color.GREEN);
        topLeftPanel.add(Box.createVerticalStrut(10));
        topLeftPanel.add(welcomePanel);
        topLeftPanel.add(logOutPanel);
        
        ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/eclipse-workspace/131Project/Images/Restaurant3.jpeg");
        Image picture = image.getImage();
        Image newImage = picture.getScaledInstance(1000,300,Image.SCALE_SMOOTH);
        image = new ImageIcon(newImage);
        JLabel imageLabel = new JLabel(image);
        
        JPanel resultPanel = new JPanel();
        resultPanel.add(Box.createHorizontalStrut(100));
        resultPanel.add(result);
        resultPanel.setMaximumSize(new Dimension(600,500));
        
        JPanel restaurantPanel = new JPanel();
        restaurantPanel.setBackground(Color.BLUE);
        restaurantPanel.add(name);
        restaurantPanel.add(Box.createHorizontalStrut(50));
        restaurantPanel.add(displayReview);
        restaurantPanel.add(Box.createHorizontalStrut(50));
        restaurantPanel.add(writeReview);
        restaurantPanel.add(Box.createHorizontalStrut(50));
        restaurantPanel.add(newSearch);
        
        JPanel combinedPanel = new JPanel();
        combinedPanel.setLayout(new BoxLayout(combinedPanel, BoxLayout.PAGE_AXIS));
        combinedPanel.add(imageLabel);
        combinedPanel.add(Box.createVerticalStrut(50));
        combinedPanel.add(resultPanel);
        combinedPanel.add(restaurantPanel);
        
        JPanel finalPanel = new JPanel(new BorderLayout());
        finalPanel.add(combinedPanel, BorderLayout.CENTER);
        finalPanel.add(topLeftPanel, BorderLayout.EAST);
        
        newSearch.addActionListener(new ActionListener()   {
            public void actionPerformed(ActionEvent e)
            {
                hideScreen();         
                SearchScreen search = new SearchScreen();
                search.createPage();
            }
        });
        
        displayReview.addActionListener(new ActionListener()   {
        	     public void actionPerformed(ActionEvent e)
        	     {
        	    	    hideScreen();
        	    	    ArrayList<String> reviews = LoginDao.getReviews(restaurantName);
        	    	    DisplayReviewsScreen screen = new DisplayReviewsScreen();
        	    	    screen.createScreen(restaurantName, reviews);
        	     }
        });
        
        logOutButton.addActionListener(new ActionListener()   {
               public void actionPerformed(ActionEvent e)
               {
                   LogOutScreen screen = new LogOutScreen();
                   screen.createLogOutFrame();
                }
        });
        
        writeReview.addActionListener(new ActionListener()   {
               public void actionPerformed(ActionEvent e)
               {
                   hideScreen();
                   ReviewScreen screen = new ReviewScreen();
                   screen.createReviewScreen(restaurantName);
                }
        });
        searchResultFrame.setPreferredSize(new Dimension(2000,2000));
        searchResultFrame.add(finalPanel);
        searchResultFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        searchResultFrame.pack();
        searchResultFrame.setVisible(true);
    }
    
    public void hideScreen()
    {
       searchResultFrame.setVisible(false);   
    }
}
