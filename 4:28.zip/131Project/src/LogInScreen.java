import javax.swing.*;
import java.awt.Dimension;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
/**
 *  This class is responsible for creating, updating and maintaining 
 *  the log in screen of the program by communicating with 
 *  model (user database) of the program.
 *
 * Team 7 Restaurant Review Application
 * @version 1.0
 */
public class LogInScreen extends JFrame
{  
  private JFrame logInFrame;  // instance variable for the log in frame
  
  /********************************
   *  This method is responsible for creating and organizing the layout of
   *  the log in page
   *  
   *  @version 1.0
   */
  public void createLogInPage()
  {
     // create new frame and components of the frame (button, labels,
     // text field, password field)
     logInFrame = new JFrame("Log in frame");
     logInFrame.setPreferredSize(new Dimension(2000,2000));
     JButton logIn = new JButton("Log in");
     JButton createAccount = new JButton("Create account");
     JLabel topLabel = new JLabel("Please log in to continue");
     topLabel.setForeground(Color.BLUE);
     topLabel.setFont(new Font("Sarif", Font.PLAIN, 40));
     JLabel logInLabel = new JLabel("Log in: ");
     JLabel passwordLabel = new JLabel("Password: ");
     JTextField logInField = new JTextField();
     logInField.setPreferredSize(new Dimension(150,20));
     JPasswordField passwordField = new JPasswordField();
     passwordField.setPreferredSize(new Dimension(150,20));
     
     // create JPanel for the greeting
     JPanel greetingPanel = new JPanel();
     greetingPanel.add(Box.createHorizontalStrut(200));
     greetingPanel.setBackground(Color.RED);
     greetingPanel.add(topLabel);
     
     // create the JPanel for username and password labels;
     // put both of these components into this panel
     JPanel labelPanel = new JPanel();
     labelPanel.setLayout(new BoxLayout(labelPanel, BoxLayout.PAGE_AXIS));
     labelPanel.add(Box.createVerticalStrut(60));
     labelPanel.add(logInLabel);
     labelPanel.add(Box.createVerticalStrut(12));
     labelPanel.add(passwordLabel);
     
     JPanel logInManagement = new JPanel();
     logInManagement.add(createAccount);
     logInManagement.add(logIn);
     
     // create the JPanel for text field and password field;
     // put both of these components into this panel
     JPanel textFieldPanel = new JPanel();
     textFieldPanel.setBackground(Color.GREEN);
     textFieldPanel.setLayout(new BoxLayout(textFieldPanel, BoxLayout.PAGE_AXIS));
     textFieldPanel.add(Box.createVerticalStrut(100));
     textFieldPanel.add(logInField);
     textFieldPanel.add(Box.createVerticalStrut(10));
     textFieldPanel.add(passwordField);
     textFieldPanel.add(Box.createVerticalStrut(10));
     textFieldPanel.add(logInManagement);
     
     // create a panel for a restaurant image (for decoration purposes);
     // put image into this panel
     ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/eclipse-workspace/131Project/Images/LogIn.jpg");
     Image temp = image.getImage();
     Image newImage = temp.getScaledInstance(1000,500,Image.SCALE_SMOOTH);
     image = new ImageIcon(newImage);
     JLabel label = new JLabel(image);
     JPanel imagePanel = new JPanel();
     imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.PAGE_AXIS));
     imagePanel.add(Box.createVerticalStrut(40));
     imagePanel.add(greetingPanel);
     imagePanel.add(label);
     
     // create a JPanel for the image and greeting
     JPanel westPane = new JPanel();
     westPane.add(Box.createHorizontalStrut(150));
     westPane.add(imagePanel);
     
     // create JPanel with default FlowLayout; put panels containing
     // labels and textfields into this bigger panel
     JPanel panel = new JPanel();
     panel.add(labelPanel);
     panel.add(textFieldPanel);
   
     // create big JPanel and add panel with image to it
     JPanel finalPanel = new JPanel(new BorderLayout());
     finalPanel.add(westPane, BorderLayout.CENTER);
     
     // add panel containing labels and text fields into the right side
     // of the big panel
     finalPanel.add(panel, BorderLayout.EAST);
     logInFrame.add(finalPanel);
       
     // action listener for the "Log in" button
     logIn.addActionListener(new ActionListener()  {
         public void actionPerformed(ActionEvent e)
         {
            String username = logInField.getText(); // get username
            String password = passwordField.getText(); // get password
            if(LoginDao.validateLogIn(username, password))
            {
            	   hideScreen();
            	   SearchScreen.username = username;
            	   SearchScreen screen = new SearchScreen();
            	   screen.createPage();
            }
            else
            {
            	   // display message to user
            	   logInField.requestFocusInWindow();
                JOptionPane.showMessageDialog(logInFrame,"You have entered " +
                     "incorrect username or password. Please try again.");
                // reset log in and password fields
                logInField.setText("");
                passwordField.setText("");
            }       
           }
        });
     
     createAccount.addActionListener(new ActionListener()   {
    	      public void actionPerformed(ActionEvent e)
    	      {
    	    	     hideScreen();
    	    	     CreateAccountFrame screen = new CreateAccountFrame();
    	    	     screen.createFrame();
    	      }
     });
     
     logInFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
     logInFrame.pack();
     logInFrame.setVisible(true);
    }
  
  /****************************
   * This method hides the log in screen
   * 
   * @version 1.0
   */
  public void hideScreen()
  {
     this.logInFrame.setVisible(false);    
  }
}