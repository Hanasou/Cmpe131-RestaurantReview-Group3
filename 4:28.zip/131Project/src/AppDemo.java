import java.util.ArrayList;

/**
 * This class was created for testing purposes only. Use it to test the 
 * log in requirement of the program
 *
 * Team 7 Restaurant Review Application
 * @version 1.0
 */
public class AppDemo
{
	
  public static void main(String[] args)
  {
        LogInScreen manager = new LogInScreen();
        manager.createLogInPage();
//	  System.out.println(LoginDao.validateLogIn("Alex","VivaLasVegas"));
//	  System.out.println(LoginDao.isInDatabase("Chop Styx"));
   //     System.out.println(LoginDao.insertInUserDatabase("Test", "hello"));
  //      System.out.println(LoginDao.insert("Subway", "Great place!"));
//	 ArrayList<String> array = new ArrayList();
//	 array.add("Great Choice");
//	 array.add("Oh say can you see, by the dawn's early light, what so proudly we hailed at the twilight's white gleaming. Whose broad stripes and bright stars through the perilous fight o'ver the ramparts we watched were so gallantly streaming.");
//	 array.add("Fantastic place to eat!");
//	 DisplayReviewsScreen screen = new DisplayReviewsScreen();
//	 screen.createScreen("Subway", array);
   }
   
}
