import javax.swing.*;
import java.awt.event.*;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.util.ArrayList;
/**
 * This class is responsible for creating and maintaining the Search
 * screen of the program. It communicates with the model (restaurant database)
 * of the program which contains the list of restaurants.
 *
 * Team 7 Restaurant Review Application
 * @version 1.0
 */
public class SearchScreen extends JFrame
{  
   private JFrame searchFrame; // instance variable for the JFrame of search page
   public static String username; 
  /***********************************
   *  This method is responsible for creating and organizing the layout of
   *  the Search page
   *  
   *  @param a string representing a username of a user
   *  @version 1.0
   */
  public void createPage()
     {
        // create a new search frame and all JComponents of the page 
        // (2 labels, a text field and a button)
        searchFrame = new JFrame("Search Frame");
        JButton logOutButton = new JButton("Log out");
        JLabel searchLabel = new JLabel("Search");
        JLabel topLabel = new JLabel("Welcome! Let's find a restaurant you like!");
        topLabel.setForeground(Color.RED);
        topLabel.setFont(new Font("Serif", Font.PLAIN, 30));
        JLabel welcomeLabel = new JLabel("You are logged in as "
                    + username);
        welcomeLabel.setFont(new Font("Serif", Font.PLAIN, 22));
        JTextField searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(300,20));
        JButton searchButton = new JButton("Search");
        
        // create a welcome panel and add a welcome label to it
        JPanel welcomePanel = new JPanel();   
        welcomePanel.setBackground(Color.BLUE);
        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createHorizontalStrut(10));
        
        // create a JPanel for log in status and log out button
        JPanel statusPanel = new JPanel();
        statusPanel.setBackground(Color.BLUE);
        statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.PAGE_AXIS));
        statusPanel.add(welcomePanel);
        statusPanel.add(logOutButton);
        
        // create a panel that will be put on the right side of the page
        // and add the east panel to it
        JPanel eastPanel = new JPanel();
        eastPanel.add(statusPanel);
        
        // create a search panel and add a search label, search text field
        // and search button to it
        JPanel searchPanel = new JPanel();
        searchPanel.add(Box.createHorizontalStrut(400));
        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
             
        // create a panel that will be put at the center of the page and
        // add the search panel created in the previous step to the middle
        // of this panel; add image to this panel
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
        ImageIcon image = new ImageIcon("/Users/aliaksandrnenartovich/eclipse-workspace/131Project/Images/RestaurantImage.jpeg");
        Image picture = image.getImage();
        Image newImage = picture.getScaledInstance(800,300,Image.SCALE_SMOOTH);
        image = new ImageIcon(newImage);
        JLabel restaurantLabel = new JLabel(image);    
        centerPanel.add(Box.createVerticalStrut(50));
        centerPanel.add(topLabel);
        centerPanel.add(restaurantLabel);
        centerPanel.add(searchPanel);
        
        // create the final big panel of the page and use its layout to
        // organize center panel and panel on the right side of the page
        JPanel finalPanel = new JPanel(new BorderLayout());
        finalPanel.add(centerPanel,BorderLayout.CENTER);
        finalPanel.add(eastPanel,BorderLayout.EAST);
            
        searchButton.addActionListener(new ActionListener()   {
            public void actionPerformed(ActionEvent e)
            {
            	    hideScreen();
                String name = searchField.getText();
                if(LoginDao.isInDatabase(name))
                {
                	 SearchScreenResult search = new SearchScreenResult();
                  search.createFoundRestaurantScreen(name);
                }                
                else
                {
                	  NoResultsScreen screen = new NoResultsScreen();
                   screen.createNoFoundRestaurantScreen(name);
                }
            }
            
        });
        
        logOutButton.addActionListener(new ActionListener()   {
            public void actionPerformed(ActionEvent e)
            {
                hideScreen();
                LogOutScreen manager = new LogOutScreen();
                manager.createLogOutFrame();
            }    
        });
               
        // add final panel to the frame
        searchFrame.add(finalPanel); 
        searchFrame.setPreferredSize(new Dimension(2000,2000));
        searchFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        searchFrame.pack();
        searchFrame.setVisible(true);
       }
       
  public void hideScreen()
  {
     searchFrame.setVisible(false); 
    }
}